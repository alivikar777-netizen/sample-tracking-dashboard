const SHEET_ID = "142xiSUpVUdMGkFkzvyFBCPp5M0J_0AtAdHlCsCUWqkg";

const ALLOWED_TABS = new Set([
  "All Samples",
  "Government Contract Sample",
  "Exhibitor & Attendee Samples",
  "EXhibitior Count",
  "Business Email List Samples",
  "Funding Samples",
  "Location Wise Email List",
  "Doctors - Specialist Email List",
  "Industry Email List",
  "Title Email List",
  "Technology Users Email List",
  "E-Commerce Samples"
]);

const TIMEOUT_MS = 12000;
const MAX_CSV_BYTES = 5 * 1024 * 1024;

export default async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "Method not allowed" });
  }

  const tab = Array.isArray(req.query.tab) ? req.query.tab[0] : req.query.tab;

  if (!tab || !ALLOWED_TABS.has(tab)) {
    return res.status(400).json({ error: "Invalid sheet tab" });
  }

  const url = new URL(`https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq`);
  url.searchParams.set("tqx", "out:csv");
  url.searchParams.set("sheet", tab);
  url.searchParams.set("_", Date.now().toString());

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 SampleTrackingDashboard/1.1",
        "Accept": "text/csv,text/plain;q=0.9,*/*;q=0.1"
      },
      cache: "no-store",
      signal: controller.signal
    });

    if (!response.ok) {
      return res.status(502).json({
        error: `Google Sheets request failed (${response.status})`
      });
    }

    const contentLength = Number(response.headers.get("content-length") || 0);
    if (contentLength > MAX_CSV_BYTES) {
      return res.status(502).json({ error: "Sheet response is unexpectedly large" });
    }

    const csv = await response.text();

    if (!csv.trim()) {
      return res.status(502).json({ error: "Google Sheets returned an empty response" });
    }

    if (/^\s*<!doctype html|^\s*<html/i.test(csv)) {
      return res.status(502).json({
        error: "Google Sheets returned HTML instead of CSV. Check sheet sharing/access."
      });
    }

    if (Buffer.byteLength(csv, "utf8") > MAX_CSV_BYTES) {
      return res.status(502).json({ error: "Sheet response is unexpectedly large" });
    }

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Cache-Control", "no-store, max-age=0");
    res.setHeader("X-Content-Type-Options", "nosniff");
    return res.status(200).send(csv);
  } catch (error) {
    if (error?.name === "AbortError") {
      return res.status(504).json({ error: "Google Sheets request timed out" });
    }

    console.error("Sheet proxy error:", error);
    return res.status(500).json({ error: "Unable to load sheet data" });
  } finally {
    clearTimeout(timer);
  }
}
